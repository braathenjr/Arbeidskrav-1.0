
/**
 * Write a description of class Clock here.
 *
 * @author Martin Braathen
 *
 */
public class Client
{
    
    public Client()
    {
    }
    
    public void MainMethod()
    {
        MeterArchive meterArchive = new MeterArchive();        
    }
}
