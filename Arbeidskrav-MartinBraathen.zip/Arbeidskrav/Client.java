
/**
 *
 * @author Martin Braathen
 *
 */
public class Client
{
    /**
     * Constructing an empty instance of Client.
     */
    public Client()
    {
    }
 
    /**
     * Creates an instance of MeterArchive, and calls the methods in its contructor.
     */
    public void MainMethod()
    {
        MeterArchive meterArchive = new MeterArchive();        
    }
}
